function DemoExternalAlert(){
    alert("External Alert.");
}
function DemoExternalConfirm(){
    if(confirm("Are you sure..??")){
        alert("yes");
    }
    else{
        alert("no");
    }
}

function DemoExternalPrompt(){
    var fName=prompt("Enter Firstname Here..");
    var IName=prompt("Enter Last Name Here..");
    alert(fName+" "+IName);
}